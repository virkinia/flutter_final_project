class Ingredient {
  final int number;
  final String name;
  Ingredient({this.number, this.name});
}
